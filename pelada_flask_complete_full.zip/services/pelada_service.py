from services.api_client import api

def listar_peladas(page=1, per_page=10):
    return api("GET", "/api/pelada/", params={"page": page, "per_page": per_page})

def criar_pelada(nome: str, cidade: str, fuso_horario: str | None = None):
    payload = {"nome": nome, "cidade": cidade}
    if fuso_horario:
        payload["fuso_horario"] = fuso_horario
    return api("POST", "/api/pelada/", json=payload)

def perfil_pelada(pelada_id: int):
    return api("GET", f"/api/pelada/{pelada_id}/perfil")

def atualizar_pelada(pelada_id: int, payload: dict):
    return api("PUT", f"/api/pelada/{pelada_id}", json=payload)
