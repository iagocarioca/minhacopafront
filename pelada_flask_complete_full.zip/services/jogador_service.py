from services.api_client import api

def listar_jogadores(pelada_id: int, page=1, per_page=50, ativo=None):
    params = {"page": page, "per_page": per_page}
    if ativo is not None:
        params["ativo"] = "true" if ativo else "false"
    return api("GET", f"/api/pelada/{pelada_id}/jogadores", params=params)

def criar_jogador(pelada_id: int, nome_completo: str, apelido: str | None, telefone: str | None):
    return api("POST", f"/api/pelada/{pelada_id}/jogadores", json={
        "nome_completo": nome_completo,
        "apelido": apelido or None,
        "telefone": telefone or None
    })

def obter_jogador(jogador_id: int):
    return api("GET", f"/api/pelada/jogadores/{jogador_id}")

def atualizar_jogador(jogador_id: int, payload: dict):
    return api("PUT", f"/api/pelada/jogadores/{jogador_id}", json=payload)
