import requests
from flask import session

API_BASE = "http://localhost:5000"

class ApiError(Exception):
    def __init__(self, status_code: int, payload: dict | None = None):
        super().__init__(payload.get("erro") if isinstance(payload, dict) and payload.get("erro") else f"API error {status_code}")
        self.status_code = status_code
        self.payload = payload or {}

def api(method: str, path: str, json=None, params=None):
    headers = {"Content-Type": "application/json"}
    token = session.get("access_token")
    if token:
        headers["Authorization"] = f"Bearer {token}"

    r = requests.request(method, API_BASE + path, json=json, params=params, headers=headers, timeout=20)
    try:
        data = r.json() if r.text else {}
    except Exception:
        data = {"erro": "Resposta inválida da API", "raw": r.text}

    if r.status_code >= 400:
        raise ApiError(r.status_code, data if isinstance(data, dict) else {"erro": "Erro", "data": data})
    return data
