from services.api_client import api

def login(email: str, senha: str):
    return api("POST", "/api/auth/login", json={"email": email, "senha": senha})

def register(email: str, senha: str, nome: str):
    return api("POST", "/api/auth/register", json={"email": email, "senha": senha, "nome": nome})

def me():
    return api("GET", "/api/users/me")

def refresh(refresh_token: str):
    # se sua API exigir refresh via header Bearer, adapte aqui
    return api("POST", "/api/auth/refresh", json=None)
