from services.api_client import api

def criar_votacao(rodada_id: int, abre_em: str, fecha_em: str, tipo: str):
    return api("POST", f"/api/pelada/rodadas/{rodada_id}/votacoes", json={
        "abre_em": abre_em,
        "fecha_em": fecha_em,
        "tipo": tipo
    })

def votar(votacao_id: int, jogador_votante_id: int, jogador_votado_id: int, pontos: int):
    return api("POST", f"/api/pelada/votacoes/{votacao_id}/votar", json={
        "jogador_votante_id": jogador_votante_id,
        "jogador_votado_id": jogador_votado_id,
        "pontos": pontos
    })
