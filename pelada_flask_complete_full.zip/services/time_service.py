from services.api_client import api

def listar_times(rodada_id: int):
    return api("GET", f"/api/pelada/rodadas/{rodada_id}/times")

def criar_time(rodada_id: int, nome: str, ordem: int):
    return api("POST", f"/api/pelada/rodadas/{rodada_id}/times", json={"nome": nome, "ordem": ordem})

def obter_time(time_id: int):
    return api("GET", f"/api/pelada/times/{time_id}")

def adicionar_jogador(time_id: int, jogador_id: int, capitao: bool, posicao: str | int | None):
    payload = {"jogador_id": jogador_id, "capitao": bool(capitao), "posicao": posicao}
    return api("POST", f"/api/pelada/times/{time_id}/jogadores", json=payload)

def remover_jogador(time_id: int, jogador_id: int):
    return api("DELETE", f"/api/pelada/times/{time_id}/jogadores/{jogador_id}")
