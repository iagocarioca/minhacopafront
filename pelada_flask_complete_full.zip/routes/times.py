from flask import Blueprint, render_template, request, redirect, url_for, flash
from services import time_service as svc
from services import jogador_service as jogador_svc
from services.api_client import ApiError

times_bp = Blueprint("times", __name__)

@times_bp.route("/rodadas/<int:rodada_id>/times", methods=["GET","POST"])
def list_create(rodada_id: int):
    if request.method == "POST":
        try:
            svc.criar_time(rodada_id, request.form.get("nome","").strip(), int(request.form.get("ordem","0")))
            flash("Time criado!", "ok")
        except ApiError as e:
            flash(e.payload.get("erro","Erro ao criar time"), "error")
        return redirect(url_for("times.list_create", rodada_id=rodada_id))

    data = svc.listar_times(rodada_id)
    return render_template("times/list.html", rodada_id=rodada_id, times=data.get("times", []))

@times_bp.route("/times/<int:time_id>", methods=["GET","POST"])
def detalhe(time_id: int):
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "add":
                svc.adicionar_jogador(
                    time_id=time_id,
                    jogador_id=int(request.form.get("jogador_id")),
                    capitao=(request.form.get("capitao") == "on"),
                    posicao=request.form.get("posicao","").strip() or None
                )
                flash("Jogador adicionado!", "ok")
            elif action == "remove":
                svc.remover_jogador(time_id, int(request.form.get("jogador_id")))
                flash("Jogador removido!", "ok")
        except ApiError as e:
            flash(e.payload.get("erro","Erro na ação"), "error")
        return redirect(url_for("times.detalhe", time_id=time_id))

    time = svc.obter_time(time_id).get("time")
    # tenta inferir pelada_id via rodada -> temporada -> pelada (se vier no payload). se não vier, lista geral não dá.
    pelada_id = None
    if isinstance(time, dict):
        pelada_id = time.get("pelada_id")  # se existir
    jogadores_disponiveis = []
    if pelada_id:
        jogadores_disponiveis = jogador_svc.listar_jogadores(pelada_id, per_page=200).get("items", [])
    return render_template("times/detalhe.html", time=time, jogadores_disponiveis=jogadores_disponiveis)
