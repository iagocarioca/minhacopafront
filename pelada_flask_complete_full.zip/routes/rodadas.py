from flask import Blueprint, render_template, request, redirect, url_for, flash
from services import rodada_service as svc
from services.api_client import ApiError

rodadas_bp = Blueprint("rodadas", __name__)

@rodadas_bp.route("/temporadas/<int:temporada_id>/rodadas", methods=["GET","POST"])
def list_create(temporada_id: int):
    if request.method == "POST":
        try:
            svc.criar_rodada(
                temporada_id,
                request.form.get("data_rodada","").strip(),
                int(request.form.get("quantidade_times","0")),
                int(request.form.get("jogadores_por_time","0")),
            )
            flash("Rodada criada!", "ok")
        except ApiError as e:
            flash(e.payload.get("erro","Erro ao criar rodada"), "error")
        return redirect(url_for("rodadas.list_create", temporada_id=temporada_id))

    data = svc.listar_rodadas(temporada_id, page=int(request.args.get("page","1")), per_page=10)
    return render_template("rodadas/list.html", temporada_id=temporada_id, data=data)

@rodadas_bp.route("/rodadas/<int:rodada_id>")
def detalhe(rodada_id: int):
    data = svc.obter_rodada(rodada_id)
    return render_template("rodadas/detalhe.html", rodada=data.get("rodada"))
