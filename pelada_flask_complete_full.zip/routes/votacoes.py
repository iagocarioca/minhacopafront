from flask import Blueprint, render_template, request, redirect, url_for, flash
from services import votacao_service as svc
from services.api_client import ApiError

votacoes_bp = Blueprint("votacoes", __name__)

@votacoes_bp.route("/rodadas/<int:rodada_id>/votacoes", methods=["GET","POST"])
def criar(rodada_id: int):
    if request.method == "POST":
        try:
            svc.criar_votacao(
                rodada_id,
                request.form.get("abre_em","").strip(),
                request.form.get("fecha_em","").strip(),
                request.form.get("tipo","").strip()
            )
            flash("Votação criada!", "ok")
        except ApiError as e:
            flash(e.payload.get("erro","Erro ao criar votação"), "error")
        return redirect(url_for("votacoes.criar", rodada_id=rodada_id))
    return render_template("votacoes/create.html", rodada_id=rodada_id)

@votacoes_bp.route("/votacoes/<int:votacao_id>/votar", methods=["GET","POST"])
def votar(votacao_id: int):
    if request.method == "POST":
        try:
            svc.votar(
                votacao_id,
                int(request.form.get("jogador_votante_id")),
                int(request.form.get("jogador_votado_id")),
                int(request.form.get("pontos")),
            )
            flash("Voto registrado!", "ok")
        except ApiError as e:
            flash(e.payload.get("erro","Erro ao votar"), "error")
        return redirect(url_for("votacoes.votar", votacao_id=votacao_id))
    return render_template("votacoes/votar.html", votacao_id=votacao_id)
