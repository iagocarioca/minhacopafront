from flask import Blueprint, render_template, request, redirect, url_for, flash
from services import temporada_service as svc
from services.api_client import ApiError

temporadas_bp = Blueprint("temporadas", __name__)

@temporadas_bp.route("/peladas/<int:pelada_id>/temporadas", methods=["GET","POST"])
def list_create(pelada_id: int):
    if request.method == "POST":
        try:
            svc.criar_temporada(pelada_id, request.form.get("inicio_mes","").strip(), request.form.get("fim_mes","").strip())
            flash("Temporada criada!", "ok")
        except ApiError as e:
            flash(e.payload.get("erro","Erro ao criar temporada"), "error")
        return redirect(url_for("temporadas.list_create", pelada_id=pelada_id))

    data = svc.listar_temporadas(pelada_id, page=int(request.args.get("page","1")), per_page=10)
    return render_template("temporadas/list.html", pelada_id=pelada_id, data=data)

@temporadas_bp.route("/temporadas/<int:temporada_id>", methods=["GET","POST"])
def detalhe(temporada_id: int):
    if request.method == "POST":
        if request.form.get("action") == "encerrar":
            try:
                svc.encerrar_temporada(temporada_id)
                flash("Temporada encerrada!", "ok")
            except ApiError as e:
                flash(e.payload.get("erro","Erro ao encerrar"), "error")
            return redirect(url_for("temporadas.detalhe", temporada_id=temporada_id))

    data = svc.obter_temporada(temporada_id)
    return render_template("temporadas/detalhe.html", temporada=data.get("temporada"))
