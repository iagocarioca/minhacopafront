from flask import Blueprint, render_template, request, redirect, url_for, flash
from services import pelada_service as svc
from services.api_client import ApiError

peladas_bp = Blueprint("peladas", __name__, url_prefix="")

@peladas_bp.route("/peladas", methods=["GET", "POST"])
def list_create():
    if request.method == "POST":
        try:
            svc.criar_pelada(
                nome=request.form.get("nome","").strip(),
                cidade=request.form.get("cidade","").strip(),
                fuso_horario=request.form.get("fuso_horario","").strip() or None
            )
            flash("Pelada criada!", "ok")
        except ApiError as e:
            flash(e.payload.get("erro","Erro ao criar pelada"), "error")
        return redirect(url_for("peladas.list_create"))

    page = int(request.args.get("page", "1"))
    data = svc.listar_peladas(page=page, per_page=10)
    return render_template("peladas/list.html", data=data)

@peladas_bp.route("/peladas/<int:pelada_id>")
def perfil(pelada_id: int):
    data = svc.perfil_pelada(pelada_id)
    return render_template("peladas/perfil.html", **data)

@peladas_bp.route("/peladas/<int:pelada_id>/edit", methods=["GET", "POST"])
def editar(pelada_id: int):
    if request.method == "POST":
        payload = {k:v for k,v in {
            "nome": request.form.get("nome","").strip() or None,
            "cidade": request.form.get("cidade","").strip() or None,
            "fuso_horario": request.form.get("fuso_horario","").strip() or None,
            "ativa": True if request.form.get("ativa") == "on" else False
        }.items() if v is not None}
        try:
            svc.atualizar_pelada(pelada_id, payload)
            flash("Pelada atualizada!", "ok")
            return redirect(url_for("peladas.perfil", pelada_id=pelada_id))
        except ApiError as e:
            flash(e.payload.get("erro","Erro ao atualizar"), "error")

    data = svc.perfil_pelada(pelada_id)
    return render_template("peladas/edit.html", **data)
