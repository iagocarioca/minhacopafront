from flask import Blueprint, render_template, request
from services import ranking_service as svc

rankings_bp = Blueprint("rankings", __name__)

@rankings_bp.route("/temporadas/<int:temporada_id>/ranking")
def hub(temporada_id: int):
    return render_template("rankings/hub.html", temporada_id=temporada_id)

@rankings_bp.route("/temporadas/<int:temporada_id>/ranking/times")
def times(temporada_id: int):
    data = svc.ranking_times(temporada_id)
    return render_template("rankings/times.html", temporada_id=temporada_id, ranking=data.get("ranking", []))

@rankings_bp.route("/temporadas/<int:temporada_id>/ranking/artilheiros")
def artilheiros(temporada_id: int):
    limit = int(request.args.get("limit", "10"))
    data = svc.ranking_artilheiros(temporada_id, limit=limit)
    return render_template("rankings/artilheiros.html", temporada_id=temporada_id, ranking=data.get("ranking", []), limit=limit)

@rankings_bp.route("/temporadas/<int:temporada_id>/ranking/assistencias")
def assistencias(temporada_id: int):
    limit = int(request.args.get("limit", "10"))
    data = svc.ranking_assistencias(temporada_id, limit=limit)
    return render_template("rankings/assistencias.html", temporada_id=temporada_id, ranking=data.get("ranking", []), limit=limit)
