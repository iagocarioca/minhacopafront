from flask import Blueprint, render_template, request, redirect, url_for, flash
from services import jogador_service as svc
from services.api_client import ApiError

jogadores_bp = Blueprint("jogadores", __name__)

@jogadores_bp.route("/peladas/<int:pelada_id>/jogadores", methods=["GET", "POST"])
def list_create(pelada_id: int):
    if request.method == "POST":
        try:
            svc.criar_jogador(
                pelada_id,
                request.form.get("nome_completo","").strip(),
                request.form.get("apelido","").strip() or None,
                request.form.get("telefone","").strip() or None,
            )
            flash("Jogador criado!", "ok")
        except ApiError as e:
            flash(e.payload.get("erro","Erro ao criar jogador"), "error")
        return redirect(url_for("jogadores.list_create", pelada_id=pelada_id))

    data = svc.listar_jogadores(pelada_id, page=int(request.args.get("page","1")), per_page=50, ativo=None)
    return render_template("jogadores/list.html", pelada_id=pelada_id, data=data)

@jogadores_bp.route("/jogadores/<int:jogador_id>/edit", methods=["GET","POST"])
def edit(jogador_id: int):
    if request.method == "POST":
        payload = {
            "nome_completo": request.form.get("nome_completo","").strip(),
            "apelido": request.form.get("apelido","").strip() or None,
            "telefone": request.form.get("telefone","").strip() or None,
            "ativo": True if request.form.get("ativo") == "on" else False
        }
        try:
            data = svc.atualizar_jogador(jogador_id, payload)
            flash("Jogador atualizado!", "ok")
            pelada_id = data.get("jogador", {}).get("pelada_id")
            if pelada_id:
                return redirect(url_for("jogadores.list_create", pelada_id=pelada_id))
        except ApiError as e:
            flash(e.payload.get("erro","Erro ao atualizar"), "error")

    data = svc.obter_jogador(jogador_id)
    return render_template("jogadores/edit.html", jogador=data.get("jogador"))
