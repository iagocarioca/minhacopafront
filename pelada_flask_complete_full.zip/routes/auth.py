from flask import Blueprint, render_template, request, redirect, session, url_for, flash
from services.auth_service import login as api_login, register as api_register
from services.api_client import ApiError

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        try:
            data = api_login(request.form.get("email","").strip(), request.form.get("senha",""))
            session["access_token"] = data.get("access_token")
            session["refresh_token"] = data.get("refresh_token")
            return redirect(url_for("peladas.list_create"))
        except ApiError as e:
            flash(e.payload.get("erro","Falha no login"), "error")
    return render_template("auth/login.html")

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        try:
            api_register(
                request.form.get("email","").strip(),
                request.form.get("senha",""),
                request.form.get("nome","").strip()
            )
            flash("Conta criada! Faça login.", "ok")
            return redirect(url_for("auth.login"))
        except ApiError as e:
            flash(e.payload.get("erro","Falha no cadastro"), "error")
    return render_template("auth/register.html")

@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
