from flask import Flask, redirect, url_for, session, request
from routes.auth import auth_bp
from routes.peladas import peladas_bp
from routes.jogadores import jogadores_bp
from routes.temporadas import temporadas_bp
from routes.rodadas import rodadas_bp
from routes.times import times_bp
from routes.partidas import partidas_bp
from routes.rankings import rankings_bp
from routes.votacoes import votacoes_bp

def create_app():
    app = Flask(__name__)
    app.secret_key = "super-secret-key"  # troque em prod

    @app.before_request
    def _auth_guard():
        public_paths = {"/login", "/register"}
        if request.path.startswith("/static/"):
            return None
        if request.path in public_paths:
            return None
        if request.path == "/":
            return redirect(url_for("peladas.list_create"))
        if not session.get("access_token"):
            return redirect(url_for("auth.login"))
        return None

    app.register_blueprint(auth_bp)
    app.register_blueprint(peladas_bp)
    app.register_blueprint(jogadores_bp)
    app.register_blueprint(temporadas_bp)
    app.register_blueprint(rodadas_bp)
    app.register_blueprint(times_bp)
    app.register_blueprint(partidas_bp)
    app.register_blueprint(rankings_bp)
    app.register_blueprint(votacoes_bp)

    return app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
