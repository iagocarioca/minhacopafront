
from flask import Flask
from routes.auth import auth_bp
from routes.peladas import peladas_bp
from routes.temporadas import temporadas_bp
from routes.rodadas import rodadas_bp
from routes.times import times_bp
from routes.partidas import partidas_bp
from routes.rankings import rankings_bp

app = Flask(__name__)
app.secret_key = "super-secret-key"

app.register_blueprint(auth_bp)
app.register_blueprint(peladas_bp)
app.register_blueprint(temporadas_bp)
app.register_blueprint(rodadas_bp)
app.register_blueprint(times_bp)
app.register_blueprint(partidas_bp)
app.register_blueprint(rankings_bp)

if __name__ == "__main__":
    app.run(debug=True)
