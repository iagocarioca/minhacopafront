
from flask import Blueprint, render_template, request, redirect
from services.api_client import api

rodadas_bp = Blueprint("rodadas", __name__)

@rodadas_bp.route("/temporadas/<int:temporada_id>/rodadas", methods=["GET","POST"])
def rodadas(temporada_id):
    if request.method == "POST":
        api("POST", f"/api/pelada/temporadas/{temporada_id}/rodadas", {
            "data_rodada": request.form["data_rodada"],
            "quantidade_times": int(request.form["quantidade_times"]),
            "jogadores_por_time": int(request.form["jogadores_por_time"])
        })
        return redirect(request.path)
    data = api("GET", f"/api/pelada/temporadas/{temporada_id}/rodadas")
    return render_template("rodadas/list.html", rodadas=data.get("items", []), temporada_id=temporada_id)
