
from flask import Blueprint, render_template, request, redirect
from services.api_client import api

temporadas_bp = Blueprint("temporadas", __name__)

@temporadas_bp.route("/peladas/<int:pelada_id>/temporadas", methods=["GET","POST"])
def temporadas(pelada_id):
    if request.method == "POST":
        api("POST", f"/api/pelada/{pelada_id}/temporadas", {
            "inicio_mes": request.form["inicio_mes"],
            "fim_mes": request.form["fim_mes"]
        })
        return redirect(request.path)
    data = api("GET", f"/api/pelada/{pelada_id}/temporadas")
    return render_template("temporadas/list.html", temporadas=data.get("items", []), pelada_id=pelada_id)
