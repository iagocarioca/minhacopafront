
from flask import Blueprint, render_template
from services.api_client import api

rankings_bp = Blueprint("rankings", __name__)

@rankings_bp.route("/temporadas/<int:temporada_id>/ranking/times")
def ranking_times(temporada_id):
    data = api("GET", f"/api/pelada/temporadas/{temporada_id}/ranking/times")
    return render_template("rankings/times.html", ranking=data.get("ranking", []))
