
from flask import Blueprint, render_template, request, redirect
from services.api_client import api

partidas_bp = Blueprint("partidas", __name__)

@partidas_bp.route("/rodadas/<int:rodada_id>/partidas", methods=["GET","POST"])
def partidas(rodada_id):
    if request.method == "POST":
        api("POST", f"/api/pelada/rodadas/{rodada_id}/partidas", {
            "time_casa_id": int(request.form["time_casa_id"]),
            "time_fora_id": int(request.form["time_fora_id"])
        })
        return redirect(request.path)
    data = api("GET", f"/api/pelada/rodadas/{rodada_id}/partidas")
    return render_template("partidas/list.html", partidas=data.get("partidas", []), rodada_id=rodada_id)

@partidas_bp.route("/partidas/<int:partida_id>", methods=["GET","POST"])
def detalhe(partida_id):
    if request.method == "POST":
        api("POST", f"/api/pelada/partidas/{partida_id}/gols", {
            "time_id": int(request.form["time_id"]),
            "jogador_id": int(request.form["jogador_id"]),
            "minuto": int(request.form["minuto"]),
            "gol_contra": False
        })
        return redirect(request.path)
    data = api("GET", f"/api/pelada/partidas/{partida_id}")
    return render_template("partidas/detalhe.html", partida=data.get("partida"))
