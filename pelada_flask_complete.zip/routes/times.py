
from flask import Blueprint, render_template, request, redirect
from services.api_client import api

times_bp = Blueprint("times", __name__)

@times_bp.route("/rodadas/<int:rodada_id>/times", methods=["GET","POST"])
def times(rodada_id):
    if request.method == "POST":
        api("POST", f"/api/pelada/rodadas/{rodada_id}/times", {
            "nome": request.form["nome"],
            "ordem": int(request.form["ordem"])
        })
        return redirect(request.path)
    data = api("GET", f"/api/pelada/rodadas/{rodada_id}/times")
    return render_template("times/list.html", times=data.get("times", []), rodada_id=rodada_id)
