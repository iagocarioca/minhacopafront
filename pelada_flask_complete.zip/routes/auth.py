
from flask import Blueprint, render_template, request, redirect, session
from services.api_client import api

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        data = api("POST", "/api/auth/login", {
            "email": request.form["email"],
            "senha": request.form["senha"]
        })
        session["access_token"] = data["access_token"]
        return redirect("/peladas")
    return render_template("auth/login.html")

@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect("/login")
