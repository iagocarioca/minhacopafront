
from flask import Blueprint, render_template, request, redirect
from services.api_client import api

peladas_bp = Blueprint("peladas", __name__)

@peladas_bp.route("/peladas", methods=["GET","POST"])
def list_create():
    if request.method == "POST":
        api("POST", "/api/pelada/", {
            "nome": request.form["nome"],
            "cidade": request.form["cidade"]
        })
        return redirect("/peladas")
    data = api("GET", "/api/pelada/")
    return render_template("peladas/list.html", peladas=data.get("items", []))

@peladas_bp.route("/peladas/<int:pelada_id>")
def perfil(pelada_id):
    data = api("GET", f"/api/pelada/{pelada_id}/perfil")
    return render_template("peladas/perfil.html", **data)
