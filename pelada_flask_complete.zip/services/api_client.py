
import requests
from flask import session

API_BASE = "http://localhost:5000"

def api(method, path, json=None):
    headers = {"Content-Type": "application/json"}
    token = session.get("access_token")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = requests.request(method, API_BASE + path, json=json, headers=headers)
    return r.json()
